package com.example.crud_masterclass

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
